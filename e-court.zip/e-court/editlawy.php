<?php 
	session_start();
	$uname=$_SESSION['uname'];	
	if($uname)
	{
		include "lawyermenu.php";
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<title></title>
			<style type="text/css">
				th,td
				{
					padding: 20px;
					color: black;
				}
				h1
				{
					margin-top: 20px;
				}
			</style>
		</head>
		<body>
			<center>
				<form>
				<h1><u>Lawyer Profile</u></h1>
				<table>
					<?php 	
						$profile="SELECT  lawyer.name,lawyer.contact,lawyer.email,lawyer.uname,lawyer.status, lawydet.edu, lawydet.exp, lawydet.special, lawydet.lang, lawydet.court from lawyer inner join lawydet on lawyer.uname=lawydet.uname where lawyer.uname='$uname'  ";
						$res=mysqli_query($conn,$profile);
						while($row=mysqli_fetch_assoc($res))
						{ ?>
							<tr>
						<th>Name</th>
						<td><input type="" name="name" value="<?php 	echo $row['name']; ?>"></td>
					</tr>
					<tr>
						<th>Email</th>
						<td><input type="" name="email" value="<?php 	echo $row['email']; ?>"></td>
					</tr>
					<tr>
						<th>Contact</th>
						<td><input type="" name="contact" value="<?php 	echo $row['contact']; ?>"></td>
					</tr>
					<tr>
						<th>Username</th>
						<td><input type="" name="uname" value="<?php 	echo $row['uname']; ?>"></td>
					</tr>
					<tr>
						<th>Education</th>
						<td><input type="" name="edu" value="<?php 	echo $row['edu']; ?>"></td>
					</tr>
					<tr>
						<th>Experience</th>
						<td><input type="" name="exp" value="<?php 	echo $row['exp']; ?>"></td>
					</tr>
					<tr>
						<th>Special</th>
						<td><input type="" name="special" value="<?php echo $row['special'];?>"> </td>
					</tr>
					<tr>
						<th>Language Known</th>
						<td><input type="" name="lang" value="<?php 	echo $row['lang']; ?>"></td>
					</tr>
					<tr>
						<th>Court Handeled</th>
						<td><input type="" name="court" value="<?php 	echo $row['court']; ?>"></td>
					</tr>
					

					<?php	}


					 ?>
					
				</table>
				<input type="submit" name="edit" value="Update">
				</form>
			</center>
			<?php 	

				if(isset($_POST['edit']))
				{
					$name=$_POST['name'];
					$email=$_POST['email'];
					$contact=$_POST['contact'];
					$edu=$_POST['edu'];
					$exp=$_POST['exp'];
					$name=$_POST['name'];
					$name=$_POST['name'];
					$name=$_POST['name'];
				}



			 ?>
		
		</body>
		</html>
	<?php }




 ?>