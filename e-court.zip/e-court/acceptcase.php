<?php 

	include "connect.php";
	session_start();
	$uname=$_SESSION['uname'];

	$upd="UPDATE casedet set handle='$uname'";
	$res=mysqli_query($conn,$upd);
	if($res)
	{
		echo "<script>
		alert('Handeled');
		window.location='lawyviewcase.php';
		</script>";
	}
	else {
		echo "<script>
		alert('Something went wrong');
		window.location='lawyviewcase.php';
		</script>";
	}





 ?>