<?php 
	session_start();
	$uname=$_SESSION['uname'];	
	if($uname)
	{
		include "publicmenu.php";
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<title></title>
			<style type="text/css">
				th,td
				{
					padding: 20px;
					color: black;
				}
				h1
				{
					margin-top: 20px;
				}
			</style>
		</head>
		<body>
			<center>
				<h1><u>Public Profile</u></h1>
				<table>
					<?php 	
						$profile="SELECT * from client where uname='$uname' ";
						$res=mysqli_query($conn,$profile);
						while($row=mysqli_fetch_assoc($res))
						{ ?>
							<tr>
						<th>Name</th>
						<td><?php 	echo $row['name']; ?></td>
					</tr>
					<tr>
						<th>Email</th>
						<td><?php 	echo $row['email']; ?></td>
					</tr>
					<tr>
						<th>Contact</th>
						<td><?php 	echo $row['contact']; ?></td>
					</tr>
					<tr>
						<th>Username</th>
						<td><?php 	echo $row['uname']; ?></td>
					</tr>
					

					<?php	}


					 ?>
					
				</table>
			</center>
		
		</body>
		</html>
	<?php }




 ?>