<?php 
	session_start();
	$uname=$_SESSION['uname'];
	if($_SESSION['uname'])
	{
		include "connect.php";
		include "lawyermenu.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	
	<style type="text/css">
		.table 
		{
			margin-top: 10px;
		}
		h1
		{
			margin-top: 50px;
		}
	</style>
</head>
<body>
	<center><h1>Case Details</h1></center>
	<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">Case ID</th>
     	<th scope="col">Username</th>
      <th scope="col">Name</th>
      <th scope="col">Section</th>
      <th scope="col">Type</th>
      <th scope="col">Handeled</th>
     
     
    </tr>
  </thead>
  <tbody>
  	<?php 	
  		$disp="SELECT * from  casedet where handle!='none' ";
  		$res=mysqli_query($conn,$disp);
  		while($row=mysqli_fetch_assoc($res))
  		{ ?>
  			 <tr>
     				<td><?php echo $row['id']; ?></td>
     				  <td><a style="color: white;" href="lawyviewpubdet.php?uname=<?php echo $row['uname'];  ?>"><?php  echo $row['uname']; ?></a></td>
      			<td><?php echo $row['cname']; ?></td>
      			<td><?php echo $row['section']; ?></td>
      			<td><?php echo $row['ctype']; ?></td>
      			<td><?php echo $row['handle']; ?></td>
      			
      			
      			
      			
      			
    		</tr>

  		<?php }

  	 ?>
   
   
  </tbody>
</table>

</body>
</html>

<?php	}
	else
	{
		echo '<script type="text/javascript">
		window.location=("publiclogin.php");
		</script>';
	}

 ?>