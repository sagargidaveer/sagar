<?php 
	session_start();
	if($_SESSION['uname'])
	{
		include "connect.php";
		include "lawyermenu.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<style type="text/css">
		.table 
		{
			margin-top: 10px;
		}
		h1
		{
			margin-top: 50px;
		}
	</style>
</head>
<body>
	<center><h1><u>Judge Details</u></h1></center>
	<table class="table table-dark">
  <thead>
    <tr>
      
      <th scope="col">Name</th>
      <th scope="col">Contact</th>
      <th scope="col">Email</th>
      <th scope="col">Qualification</th>
      <th scope="col">Year of Experience</th>
      <th scope="col">Username</th>
     
    </tr>
  </thead>
  <tbody>
  	<?php 	
  		$disp="SELECT * from  iudge";
  		$res=mysqli_query($conn,$disp);
  		while($row=mysqli_fetch_assoc($res))
  		{ ?>
  			 <tr>
     
      			<td><?php echo $row['name']; ?></td>
      			<td><?php echo $row['contact']; ?></td>
      			<td><?php echo $row['email']; ?></td>
      			<td><?php echo $row['qualify']; ?></td>
      			<td><?php echo $row['exp']; ?></td>
      			<td><?php echo $row['username']; ?></td>
      			
    		</tr>

  		<?php }

  	 ?>
   
   
  </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<?php	}
	else
	{
		echo '<script type="text/javascript">
		window.location=("lawyerlogin.php");
		</script>';
	}

 ?>