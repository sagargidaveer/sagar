<?php 
	include "connect.php";
	$uname=$_GET['uname'];

	$del="DELETE from iudge where username='$uname' ";
	$res=mysqli_query($conn,$del);

	if($res)
	{
			echo "<script>
				alert('Data Deleted Successful');
				window.location=('adminviewjudge.php');
				</script>";
	}
	else
	{
			echo "<script>
				alert('Something went Wrong');
				window.location=('adminviewjudge.php');
				</script>";
	}



 ?>