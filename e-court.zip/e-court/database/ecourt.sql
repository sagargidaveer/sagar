-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2021 at 07:01 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecourt`
--

-- --------------------------------------------------------

--
-- Table structure for table `addlaw`
--

CREATE TABLE `addlaw` (
  `id` int(11) NOT NULL,
  `law_name` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `descp` varchar(255) NOT NULL,
  `punishment` varchar(255) NOT NULL,
  `remedy` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `casedet`
--

CREATE TABLE `casedet` (
  `id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `cname` varchar(40) NOT NULL,
  `ctype` varchar(50) NOT NULL,
  `section` varchar(40) NOT NULL,
  `handle` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casedet`
--

INSERT INTO `casedet` (`id`, `uname`, `cname`, `ctype`, `section`, `handle`) VALUES
(1, 'shree11', 'Property', 'Fraud', '123', 'pkirti10');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `name` varchar(30) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`name`, `contact`, `address`, `email`, `uname`, `password`) VALUES
('Shridevi', 8796854712, 'BGm', 'shree@gmail.com', 'shree11', 'shree11');

-- --------------------------------------------------------

--
-- Table structure for table `iudge`
--

CREATE TABLE `iudge` (
  `username` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `qualify` varchar(20) NOT NULL,
  `exp` int(11) NOT NULL,
  `pwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iudge`
--

INSERT INTO `iudge` (`username`, `name`, `contact`, `email`, `qualify`, `exp`, `pwd`) VALUES
('pkirti10', 'Kirti', 8795546301, 'pkirti11@gmail.com', 'LLB', 11, '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `judgement`
--

CREATE TABLE `judgement` (
  `id` int(11) NOT NULL,
  `caseid` int(11) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `puname` varchar(40) NOT NULL,
  `lwaymail` varchar(20) NOT NULL,
  `judgename` varchar(20) NOT NULL,
  `judgement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `judgement`
--

INSERT INTO `judgement` (`id`, `caseid`, `cname`, `puname`, `lwaymail`, `judgename`, `judgement`) VALUES
(1, 1, 'Property', 'shree11', 'pkirti10', 'shree11', 'wqwdsqd'),
(2, 1, 'Property', 'shree11', 'pkirti10', 'pkirti10', 'sdwed');

-- --------------------------------------------------------

--
-- Table structure for table `lawydet`
--

CREATE TABLE `lawydet` (
  `id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `edu` varchar(40) NOT NULL,
  `exp` int(11) NOT NULL,
  `special` varchar(60) NOT NULL,
  `lang` varchar(50) NOT NULL,
  `court` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lawydet`
--

INSERT INTO `lawydet` (`id`, `uname`, `edu`, `exp`, `special`, `lang`, `court`) VALUES
(1, 'pkirti10', 'LLB', 2, 'Criminal', 'Hindi,english', 'district');

-- --------------------------------------------------------

--
-- Table structure for table `lawyer`
--

CREATE TABLE `lawyer` (
  `name` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `uname` varchar(60) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lawyer`
--

INSERT INTO `lawyer` (`name`, `contact`, `email`, `uname`, `pass`, `status`) VALUES
('Kirti', 8795546301, 'pkirti10@gmail.com', 'pkirti10', '123456', 'reject');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addlaw`
--
ALTER TABLE `addlaw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `casedet`
--
ALTER TABLE `casedet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `iudge`
--
ALTER TABLE `iudge`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `judgement`
--
ALTER TABLE `judgement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lawydet`
--
ALTER TABLE `lawydet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lawyer`
--
ALTER TABLE `lawyer`
  ADD PRIMARY KEY (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addlaw`
--
ALTER TABLE `addlaw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `casedet`
--
ALTER TABLE `casedet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `judgement`
--
ALTER TABLE `judgement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `lawydet`
--
ALTER TABLE `lawydet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
