<?php 	
   session_start();
    $uname=$_SESSION['uname'];
	include "connect.php";
	include "judgemenu.php";
   $id=$_GET['id'];

 ?>
 <!DOCTYPE html>
 <html>
 <head>
    <meta charset="utf-8">
    <title></title>
    <style type="text/css">
       th,td
       {
         padding: 20px;
       }
    </style>
 </head>
 <body>
   <center>
      <?php 
         $disp="SELECT * from  casedet where handle!='none' ";
      $res=mysqli_query($conn,$disp);
      while($row=mysqli_fetch_assoc($res))
      { 
         $puname=$row['uname'];
         $cname=$row['cname'];
         $ctype=$row['ctype'];
         $handle=$row['handle'];

      }
       ?>
      <form method="post">
         <h1>Add Judgement Details</h1>
         <table>
            <tr>
               <th>Case Name</th>
               <td><input type="text" name="cname" value="<?php echo $cname; ?>"></td>
            </tr>
             <tr>
               <th>Type of Case</th>
               <td><input type="text" name="ctype" value="<?php echo $ctype; ?>"></td>
            </tr>
             <tr>
               <th>Judgement</th>
               <td><input type="text" name="judgement" ></td>
            </tr>

            
         </table>
         <input type="submit" name="add" value="Add Details">
         <input type="reset"  value="Cancel">
      </form>
   </center>
   <?php 
      if(isset($_POST['add']))
      {
         $cname=$_POST['cname'];
         $ctype=$_POST['ctype'];
         $judgement=$_POST['judgement'];
         

         $add="INSERT into judgement values('0','$id','$cname','$puname','$handle','$uname','$judgement') ";
         $query=mysqli_query($conn,$add);

         if($query)
         {
            echo "<script>
            alert('Added ');
            window.location=('viewjudgement.php');
            </script>";
         }
         else
         {
            echo "<script>
            alert('Failed ');
           
            </script>";
         }
      }




    ?>
 
 </body>
 </html>