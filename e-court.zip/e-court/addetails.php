<?php 	
   session_start();
    $uname=$_SESSION['uname'];
	include "connect.php";
	include "lawyermenu.php";


 ?>
 <!DOCTYPE html>
 <html>
 <head>
    <meta charset="utf-8">
    <title></title>
    <style type="text/css">
       th,td
       {
         padding: 20px;
       }
    </style>
 </head>
 <body>
   <center>
      <form method="post">
         <h1>Add Details</h1>
         <table>
            <tr>
               <th>Education</th>
               <td><input type="text" name="edu"></td>
            </tr>
             <tr>
               <th>Experience</th>
               <td><input type="text" name="exp"></td>
            </tr>
             <tr>
               <th>Specialization</th>
               <td><input type="text" name="special"></td>
            </tr>

            <tr>
               <th>Languages Known</th>
               <td><input type="text" name="lang"></td>
            </tr>

            <tr>
               <th>Practice Court</th>
               <td><input type="text" name="court"></td>
            </tr>
         </table>
         <input type="submit" name="add" value="Add Details">
         <input type="reset"  value="Cancel">
      </form>
   </center>
   <?php 
      if(isset($_POST['add']))
      {
         $edu=$_POST['edu'];
         $exp=$_POST['exp'];
         $special=$_POST['special'];
         $lang=$_POST['lang'];
         $court=$_POST['court'];

         $add="INSERT into lawydet values('0','$uname','$edu','$exp','$special','$lang','$court') ";
         $query=mysqli_query($conn,$add);

         if($query)
         {
            echo "<script>
            alert('Added ');
            window.location=('lawyerindex.php');
            </script>";
         }
         else
         {
            echo "<script>
            alert('Failed ');
           
            </script>";
         }
      }




    ?>
 
 </body>
 </html>