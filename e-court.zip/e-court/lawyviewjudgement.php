<?php 	
   session_start();
    $uname=$_SESSION['uname'];
	include "connect.php";
	include "lawyermenu.php";


 ?>
 <!DOCTYPE html>
 <html>
 <head>
    <meta charset="utf-8">
    <title></title>
    <style type="text/css">
       th,td
       {
         padding: 20px;
       }
    </style>
 </head>
 <body>
   <center><h1>Judgement Details</h1></center>
   <table class="table table-dark">
  <thead>
    <tr>
      <th scope="col"> ID</th>
      <th scope="col">Case ID</th>
      <th scope="col">Case Name</th>
      <th scope="col">Judge Username</th>
      <th scope="col">Public Username</th>
      
      <th scope="col">Judgement</th>
     
     
    </tr>
  </thead>
  <tbody>
   <?php    
      $disp="SELECT * from  judgement where lwaymail='$uname' ";
      $res=mysqli_query($conn,$disp);
      while($row=mysqli_fetch_assoc($res))
      { ?>
          <tr>
               <td><?php echo $row['id']; ?></td>
                
               <td><?php echo $row['caseid']; ?></td>
               <td><?php echo $row['cname']; ?></td>
               <td><?php echo $row['judgename']; ?></td>
               <td><?php echo $row['puname']; ?></td>
               <td><?php echo $row['judgement']; ?></td>
               
               
               
               
               
               
         </tr>

      <?php }

    ?>
   
   
  </tbody>
</table>

   <?php 
      if(isset($_POST['add']))
      {
         $cname=$_POST['cname'];
         $ctype=$_POST['ctype'];
         $section=$_POST['section'];
         

         $add="INSERT into casedet values('0','$uname','$cname','$ctype','$section','None') ";
         $query=mysqli_query($conn,$add);

         if($query)
         {
            echo "<script>
            alert('Added ');
            window.location=('publicindex.php');
            </script>";
         }
         else
         {
            echo "<script>
            alert('Failed ');
           
            </script>";
         }
      }




    ?>
 
 </body>
 </html>