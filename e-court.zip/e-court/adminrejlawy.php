<?php 
	include "connect.php";
	$uname=$_GET['uname'];

	$upd="UPDATE lawyer set status='reject' where uname='$uname'";
	$res=mysqli_query($conn,$upd);
	if($res)
	{
		echo "<script>
		alert('Rejected');
		window.location='adminviewlawy.php';
		</script>";
	}
	else
	{
		echo "<script>
		alert('Something went wrong');
		window.location='adminviewlawy.php';
		</script>";
	}



 ?>