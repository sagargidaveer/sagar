<?php 
	include "connect.php";
	$id=$_GET['id'];

	$del="DELETE from addlaw where id='$id' ";
	$res=mysqli_query($conn,$del);

	if($res)
	{
			echo "<script>
				alert('Data Deleted Successful');
				window.location=('adminviewlaw.php');
				</script>";
	}
	else
	{
			echo "<script>
				alert('Something went Wrong');
				window.location=('adminviewlaw.php');
				</script>";
	}



 ?>