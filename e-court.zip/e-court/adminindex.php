<?php 	
	include "connect.php";
	include "adminmenu.php";


 ?>