<?php 
	session_start();
	$uname=$_GET['uname'];	
	if($uname)
	{
		include "adminmenu.php";
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<title></title>
			<style type="text/css">
				th,td
				{
					padding: 20px;
					color: black;
				}
				h1
				{
					margin-top: 20px;
				}
			</style>
		</head>
		<body>
			<center>
				<form method="post">
				<h1><u>EDIT JUDGE</u></h1>
				<table>
					<?php 	
						$profile="SELECT * from iudge where username='$uname' ";
						$res=mysqli_query($conn,$profile);
						while($row=mysqli_fetch_assoc($res))
						{ ?>
							<tr>
						<th>Name</th>
						<td><input type="text" name="name" value="<?php echo $row['name']; ?>"></td>
					</tr>
					<tr>
						<th>Email</th>
						<td><input type="email" name="email" value="<?php echo $row['email']; ?>"></td>
					</tr>
					<tr>
						<th>Qualification</th>
						<td><input type="text" name="qualify" value="<?php echo $row['qualify']; ?>"></td>
					</tr>
					<tr>
						<th>Experience</th>
						<td><input type="text" name="exp" value="<?php echo $row['exp']; ?>"></td>
					</tr>
					<tr>
						<th>Contact</th>
						<td><input type="text" name="contact" value="<?php echo $row['contact']; ?>"></td>
					</tr>
					<tr>
						<th>Username</th>
						<td><input type="text" name="uname" value="<?php echo $row['username']; ?>" readonly></td>
					</tr>
					

					<?php	}


					 ?>
					
				</table>
				<input type="submit" name="update" value="UPDATE">
			</form>
			</center>
		<?php 	
		if(isset($_POST['update']))
		{
			
			$name=$_POST['name'];
			$contact=$_POST['contact'];
			$email=$_POST['email'];
			$qualify=$_POST['qualify'];
			$exp=$_POST['exp'];
			

			$update="UPDATE iudge set name='$name',contact='$contact',email='$email',qualify='$qualify',exp='$exp' where username='$uname' ";

			$res=mysqli_query($conn,$update);
			if($res)
			{
				echo "<script>
				alert('Data Updated');
				window.location='adminviewjudge.php';
				</script>";
			}
			else
			{
				echo "<script>
				alert('Data not Updated');
				window.location='adminviewjudge.php';
				</script>";
			}
		}
		?>

		</body>
		</html>
	<?php }




 ?>