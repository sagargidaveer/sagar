<?php 	
   session_start();
    $uname=$_SESSION['uname'];
	include "connect.php";
	include "publicmenu.php";


 ?>
 <!DOCTYPE html>
 <html>
 <head>
    <meta charset="utf-8">
    <title></title>
    <style type="text/css">
       th,td
       {
         padding: 20px;
       }
    </style>
 </head>
 <body>
   <center>
      <form method="post">
         <h1>Add Case Details</h1>
         <table>
            <tr>
               <th>Case Name</th>
               <td><input type="text" name="cname"></td>
            </tr>
             <tr>
               <th>Type of Case</th>
               <td><input type="text" name="ctype"></td>
            </tr>
             <tr>
               <th>Section</th>
               <td><input type="text" name="section"></td>
            </tr>

            
         </table>
         <input type="submit" name="add" value="Add Details">
         <input type="reset"  value="Cancel">
      </form>
   </center>
   <?php 
      if(isset($_POST['add']))
      {
         $cname=$_POST['cname'];
         $ctype=$_POST['ctype'];
         $section=$_POST['section'];
         

         $add="INSERT into casedet values('0','$uname','$cname','$ctype','$section','None') ";
         $query=mysqli_query($conn,$add);

         if($query)
         {
            echo "<script>
            alert('Added ');
            window.location=('publicindex.php');
            </script>";
         }
         else
         {
            echo "<script>
            alert('Failed ');
           
            </script>";
         }
      }




    ?>
 
 </body>
 </html>