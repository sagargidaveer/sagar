 <?php 	
        session_start();

		include "connect.php";
		include "mainmenu.php";
		

 ?>
 <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="login.css">
</head>

<body>

    
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-key" aria-hidden="true"></i>
                </div>
                <div class="col-lg-12 login-title">
                   LAWYER REGISTRATION PANEL
                </div>

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form method="post" action="">
                            <div class="form-group">
                                <label class="form-control-label">NAME</label>
                                <input type="text" name="name" class="form-control" required="">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">CONTACT</label>
                                <input type="text" name="contact" class="form-control" required pattern="[7-9]{1}[0-9]{9}">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">EMAIL</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">USERNAME</label>
                                <input type="text" name="uname" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">PASSWORD</label>
                                <input type="password" name="pass" class="form-control" required>
                            </div>

                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                    <!-- Error Message -->
                                </div>
                                <div class="col-lg-6 login-btm login-button">
                                    <button type="submit" class="btn btn-outline-primary" name="login">REGISTER</button> 
                                    <button type="reset" class="btn btn-outline-primary" name="login">CANCEL</button><br><br>
                                </div><br><br>
                                <h5 ><a style="margin-left:-150px;" href="lawyerlogin.php">Click Here for Login</a></h5>
                            </div>

                            
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2"></div>
            </div>
            <br><br>
        </div> 


<?php 	
		if(isset($_POST['login']))
		{
			$name=$_POST['name'];
			$contact=$_POST['contact'];
            $email=$_POST['email'];
            $uname=$_POST['uname'];
            $pass=$_POST['pass'];


			$insert="INSERT into lawyer values('$name','$contact','$email','$uname','$pass','pending') ";
			$query=mysqli_query($conn,$insert);
			

			if($query)
			{
				
				echo "<script>
				alert('Registered Successful');
				window.location=('lawyerlogin.php');
				</script>";
			}
			else
			{
				echo "<script>
				alert('Invalid username and password');
				window.location=('lawyerreg.php');
				</script>";
				die(mysqli_error($conn));
			}
		}



 ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

</body>
</html>