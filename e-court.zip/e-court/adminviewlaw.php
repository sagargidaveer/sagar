<?php 
	session_start();
	if($_SESSION['uname'])
	{
		include "connect.php";
		include "adminmenu.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<style type="text/css">
		.table 
		{
			margin-top: 10px;
		}
		h1
		{
			margin-top: 50px;
		}
	</style>
</head>
<body>
	<center><h1>Law Details</h1></center>
	<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">S.No</th>
      <th scope="col">Name</th>
      <th scope="col">Section</th>
      <th scope="col">Description</th>
      <th scope="col">Punishment</th>
      <th scope="col">Remidies</th>
      
     
    </tr>
  </thead>
  <tbody>
  	<?php 	
  		$disp="SELECT * from  addlaw";
  		$res=mysqli_query($conn,$disp);
  		while($row=mysqli_fetch_assoc($res))
  		{ ?>
  			 <tr>
     				<td><?php echo $row['id']; ?></td>
      			<td><?php echo $row['law_name']; ?></td>
      			<td><?php echo $row['section']; ?></td>
      			<td><?php echo $row['descp']; ?></td>
      			<td><?php echo $row['punishment']; ?></td>
      			<td><?php echo $row['remedy']; ?></td>
      			
      			<td><input type="button" value="EDIT" onclick="window.location='dellaw.php?id=<?php echo $row['id']; ?>'"></td>
      			<td><input type="button" value="DELETE" onclick="window.location='dellaw.php?id=<?php echo $row['id']; ?>'"></td>
      			
    		</tr>

  		<?php }

  	 ?>
   
   
  </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

<?php	}
	else
	{
		echo '<script type="text/javascript">
		window.location=("adminlogin.php");
		</script>';
	}

 ?>